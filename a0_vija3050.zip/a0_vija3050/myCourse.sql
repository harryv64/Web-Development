-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jan 11, 2017 at 08:23 PM
-- Server version: 5.7.16
-- PHP Version: 7.0.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `vija3050`
--

-- --------------------------------------------------------

--
-- Table structure for table `myCourse`
--

CREATE TABLE `myCourse` (
  `courseID` varchar(40) NOT NULL,
  `title` varchar(100) NOT NULL,
  `instructor` varchar(100) NOT NULL,
  `term` varchar(100) NOT NULL,
  `website` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `myCourse`
--

INSERT INTO `myCourse` (`courseID`, `title`, `instructor`, `term`, `website`) VALUES
('CP372', 'Computer Newtorks', 'Dr.Eugene Zima', 'Winter 2017', 'https://bohr.wlu.ca/ezima/CP_372/'),
('CP411', 'Computer Graphics', 'Dr.Hongbing Fan', 'Fall 2016', 'https://bohr.wlu.ca/hfan/cp411/16/'),
('CP414', 'Foundations of Computing', 'Dr.Eugene Zima', 'Winter 2017', 'https://bohr.wlu.ca/ezima/CP_414/'),
('CP476', 'Internet Compututing', 'Dr.Hongbing Fan', 'Winter 2017', 'https://bohr.wlu.ca/hfan/cp476/16/');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `myCourse`
--
ALTER TABLE `myCourse`
  ADD PRIMARY KEY (`courseID`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
